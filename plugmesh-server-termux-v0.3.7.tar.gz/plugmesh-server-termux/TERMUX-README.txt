Plugmesh Android Termux CLI

Install the native dependencies in Termux:
  pkg update
  pkg install clang cmake make openssl zlib tar coreutils

Run the server from this directory:
  ./plugmesh-server

The package uses the Termux native OpenSSL and zlib libraries and carries the
matching libc++_shared.so runtime beside its binaries. The plugmesh-server and
plugmesh-plugin-host launchers put this directory first in LD_LIBRARY_PATH before
starting their .bin ELF files, so an older global Termux libc++ is not selected.
It is a command-line Linux-like Termux build, not an APK and not an Android app.
The Native UI is embedded in plugmesh-server and refreshed on every start
under the Termux user's data directory. Keep the launchers, their .bin files,
libc++_shared.so, and the plugins directory together.
